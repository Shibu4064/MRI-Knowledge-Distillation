# Reviewer 1: reproduce experimental evidence for comments 1 and 2

## Setup on Kaggle
1. Attach the **original mRI dataset** as Kaggle input. Use Tesla P100/T4 GPU and Internet ON for first-run PyTorch repair only. Data discovery is inherited from the original executed pipeline.
2. For Notebook 01, attach the *selected original RTPD checkpoint* `rtpdnet_radar_student.pt` and *validation-selected CFT* `checkpoint_strong_robust.pt` (or change `CFT_CHECKPOINT` to your actual winning candidate). Existing checkpoint files are NOT included in this package and are not mounted in this chat. Check the `.pt` files came from the exact paper fixed split.
3. Run Notebook 01 top-to-bottom. Save/download `Reviewer_R1_C1_results.zip` from Kaggle Output. **Do not present fresh multi-realization means as identical to previous single-realization numbers**.
4. Run Notebook 02 top-to-bottom with mRI attached. It trains 25 fold-specific pipelines over `CV_PARTITION_SEEDS=(101,202,303,404,505)` using original full epochs and strict fold isolation. Download `Reviewer_R1_C2_results.zip`.
5. Upload **both Kaggle ZIP outputs** back into this conversation for numerical verification and manuscript revision. Save interim output directories as Kaggle Datasets if the runtime has to restart.

## Scientific/QA safeguards
- Notebook 01 preserves every paired segment prediction for clean and each corruption/realization. Confidence intervals resample all 10 exercise segments per subject together, including corruption realizations; with 4 subjects inference remains low precision. Exact subject-swap permutation has only 2^4=16 assignments.
- Notebook 02 replaces the old *global test loader* behavior and outputs correct fold-local test predictions. It applies exactly the same corrupted radar inputs to anchor and deployed model; accepted FT occurs only following validation checks. Each fold exports subject-cluster bootstrap confidence intervals for clean and mean corrupted macro-F1 differences; pooled confidence intervals resample partition seeds.
- A five-seed bootstrap treats **partition seed** as the top-level analysis unit; 25 folds are not claimed to be independent draws, and the same 20 subjects reappear across seeds.
- Resumes completed folds via `complete.json`; retained teacher/anchor/policy `.pt` files, per-fold normalization statistics, split files, paired predictions, training histories, configuration JSON and metrics facilitate audit. Set `RESUME_SOURCE` to a mounted Kaggle Dataset path when resuming across sessions.
- Inputs/architectures and P2_10 labeling are copied from `Sensors_Final_Constrained_RTPD_Finetuning_with_Ablation_CV.ipynb`. No new results are pre-populated.

## Important boundaries
- Notebook 01 requires saved checkpoints; if missing, first rerun the original successful final notebook or obtain its Kaggle Output checkpoint files. It will stop rather than fabricate models.
- Repeated 5-fold CV on 20 subjects does not create new independent participants; uncertainty estimates remain exploratory.
- This package directly addresses the NEW Reviewer 1 comments 1 and 2. Reviewer comments 3–4 and Reviewer 2 references are left for the later manuscript-editing round.
